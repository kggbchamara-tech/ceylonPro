<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />

  <title>CeylonPro</title>
  <meta content="" name="description" />
  <meta content="" name="keywords" />

  <!-- Favicons -->
  <link href="forms/logo.png" rel="icon" />
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon" />

  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet" />

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet" />
  <link
    href="assets/vendor/bootstrap/css/bootstrap.min.css"
    rel="stylesheet" />
  <link
    href="assets/vendor/bootstrap-icons/bootstrap-icons.css"
    rel="stylesheet" />
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet" />
  <link
    href="assets/vendor/glightbox/css/glightbox.min.css"
    rel="stylesheet" />
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet" />

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet" />
  <link rel="stylesheet" href="curserStyle.css" />
  <style>
    .upmouse {
      color: black;
      transition: 1.5s;
    }

    .upmouse:hover {
      color: #61cf70;
      transform: scale(0.9);
      transition: 1.5s;
    }
    .team-member {
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
            border-radius: 10px;

        }
        .team-member img {
            width: 100%;
            border-radius: 10px;
            transition: transform 0.3s ease-in-out;
        }
        .team-member:hover img {
            transform: scale(1.1);
        }
        .team-member .info {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            text-align: center;
            padding: 10px;
            opacity: 1;
            transition: opacity 0.3s ease-in-out;
        }
        .team-member:hover .info {
            opacity: 1;
            background: rgba(32, 208, 131, 0.7);
            color: black;
        }
  </style>

  <!-- ===================================================== -->
</head>

<body oncontextmenu="return false;">
  <!-- ======= Mobile nav toggle button ======= -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="d-flex flex-column">
      <div class="profile">
        <img
          src="assets/img/profile-img.jpeg"
          alt=""
          class="img-fluid rounded-circle" />
        <h1 class="text-light"><a href="index.html">Ceylon<span style="color: #61cf70;">Pro</span> Software</a></h1>
        <div class="social-links mt-3 text-center">
          <!-- <div class="nav-wrapper"> -->
          <nav>
            <a href="testCourser.html" class="twitter"><i class="bx bxl-twitter"></i></a>
            <a
              href="https://www.facebook.com/share/p/1FKTE56asC/"
              class="facebook"><i class="bx bxl-facebook"></i></a>
            <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
            <a
              href="https://www.youtube.com/channel/UCkJMISKj8-1LPaGuuJfbNMw"
              class="google-plus"><i class="bx bxl-youtube"></i></a>
            <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            <div class="cursor"></div>
          </nav>
          <!-- </div> -->
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li>
            <a href="#hero" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a>
          </li>
          <li>
            <a href="#about" class="nav-link scrollto"><i class="bx bx-user"></i> <span>About</span></a>
          </li>
          <li>
            <a href="#resume" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>SDLC</span></a>
          </li>
          <li>
            <a href="#portfolio" class="nav-link scrollto"><i class="bx bx-book-content"></i> <span>Portfolio</span></a>
          </li>
          <li>
            <a href="#services" class="nav-link scrollto"><i class="bx bx-server"></i> <span>Services</span></a>
          </li>
          <li>
            <a href="#contact" class="nav-link scrollto"><i class="bx bx-envelope"></i> <span>Contact</span></a>
          </li>
        </ul>
      </nav>
      <!-- .nav-menu -->
    </div>
  </header>
  <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section
    id="hero"
    class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h1>Ceylon<span style="color: #61cf70;">Pro</span> Software Solutions</h1>
      <p>
        We are
        <span
          class="typed"
          data-typed-items="Software Engineers, Ethical Hackers, Frontend Developers, Designers, Backend Developers, Freelancers, Mobile Application Developers, UI/UX Designers, IT Support"></span>
      </p>
    </div>
  </section>
  <!-- End Hero -->

  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">
        <div class="section-title">
          <h2>About</h2>
          <p><b>
          CeylonPro Software Solutions is a leading software development company founded in 2021 by CEO & Founder KGGB Chamara Preethi Kumara, along with his friends. With a vision to innovate and empower businesses through technology, we specialize in delivering high-quality, customized software solutions for a wide range of industries.
          </b></p>
        </div>

        <div class="row">
          <div class="col-lg-4" data-aos="fade-right">
            <img src="assets/img/com-img.png" class="img-fluid" alt="" />
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3>
              Software Development, UI/UX Designing, &amp; Ethical Hacking.
            </h3>
            <!-- <p class="fst-italic">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p> -->
            <div class="row">
              <div class="col-lg-6">
                <ul>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-filetype-html"></i> <span>HTML</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-filetype-css"></i> <span>CSS</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-filetype-js"></i> <span>JavaScript</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-code-slash"></i> <span>Programming</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-filetype-php"></i> <span>PHP</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-layout-text-sidebar-reverse"></i> <span>Wireframes</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-grid-1x2"></i> <span>UI Components</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-braces"></i> <span>Coding</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-hdd-network"></i> <span>Networking</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-filetype-py"></i> <span>Python</span></strong>
                  </li>
                  
                </ul>
              </div>

              <div class="col-lg-6">
                <ul>
                  <li>
                    <i class="bi bi-chevron-right"></i> <strong><i class="bi bi-database"></i> <span>Databases</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-palette"></i> <span>Design</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-megaphone"></i> <span>Marketing</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-graph-up"></i> <span>SEO</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-shield-lock"></i> <span>Cybersecurity</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-globe"></i> <span>Web Analytics</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-diagram-3"></i> <span>Project Planning</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-kanban"></i> <span>Agile</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-bar-chart"></i> <span>Data Analysis</span></strong>
                  </li>
                  <li>
                    <i class="bi bi-chevron-right"></i>
                    <strong><i class="bi bi-filetype-java"></i> <span>Java</span></strong>
                  </li>
                </ul>
              </div>
            </div>
            <!-- <p>
              Officiis eligendi itaque labore et dolorum mollitia officiis optio vero. Quisquam sunt adipisci omnis et ut. Nulla accusantium dolor incidunt officia tempore. Et eius omnis.
              Cupiditate ut dicta maxime officiis quidem quia. Sed et consectetur qui quia repellendus itaque neque. Aliquid amet quidem ut quaerat cupiditate. Ab et eum qui repellendus omnis culpa magni laudantium dolores.
            </p> -->
          </div>
        </div>
      </div>
    </section>
    <!-- End About Section -->

    <!-- ======= Facts Section ======= -->
    <section id="facts" class="facts">
      <div class="container">
        <div class="section-title">
          <h2>Facts</h2>
          <!-- <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p> -->
        </div>

        <div class="row no-gutters">
          <div
            class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch"
            data-aos="fade-up">
            <div class="count-box">
              <i class="bi bi-emoji-smile"></i>
              <span
                data-purecounter-start="0"
                data-purecounter-end="100"
                data-purecounter-duration="1"
                class="purecounter"></span>
              <p><strong>Happy Clients</strong> consequuntur quae</p>
            </div>
          </div>

          <div
            class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch"
            data-aos="fade-up"
            data-aos-delay="100">
            <div class="count-box">
              <i class="bi bi-journal-richtext"></i>
              <span
                data-purecounter-start="0"
                data-purecounter-end="100"
                data-purecounter-duration="1"
                class="purecounter"></span>
              <p><strong>Projects</strong> adipisci atque cum quia aut</p>
            </div>
          </div>

          <div
            class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch"
            data-aos="fade-up"
            data-aos-delay="200">
            <div class="count-box">
              <i class="bi bi-headset"></i>
              <span
                data-purecounter-start="0"
                data-purecounter-end="9880"
                data-purecounter-duration="1"
                class="purecounter"></span>
              <p><strong>Hours Of Support</strong> aut commodi quaerat</p>
            </div>
          </div>

          <div
            class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch"
            data-aos="fade-up"
            data-aos-delay="300">
            <div class="count-box">
              <i class="bi bi-people"></i>
              <span
                data-purecounter-start="0"
                data-purecounter-end="100"
                data-purecounter-duration="1"
                class="purecounter"></span>
              <p><strong>Hard Workers</strong> rerum asperiores dolor</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Facts Section -->

    <!-- ======= Skills Section ======= -->
    <section id="skills" class="skills section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Skills</h2>
          <p>
            We have a diverse set of skills and experience across various areas
            of software engineering and design. Some of our key skills include.
          </p>
        </div>

        <div class="row skills-content">
          <div class="col-lg-6" data-aos="fade-up">
            <div class="progress">
              <span class="skill">HTML <i class="val">99%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="99"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">CSS <i class="val">99%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="99"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">JavaScript <i class="val">99%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="99"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Bootstrap <i class="val">99%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="99"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">jQuery <i class="val">75%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="75"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Python <i class="val">85%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="85"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Ethical Hacking <i class="val">90%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="90"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Figma <i class="val">95%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="95"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>
          </div>

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="progress">
              <span class="skill">PHP <i class="val">99%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="99"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Java <i class="val">80%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="80"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">WordPress/CMS <i class="val">90%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="90"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">React Native <i class="val">90%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="90"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">MySQL <i class="val">99%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="99"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Photoshop <i class="val">98%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="98"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Cyber Security <i class="val">85%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="85"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Laravel <i class="val">90%</i></span>
              <div class="progress-bar-wrap">
                <div
                  class="progress-bar"
                  role="progressbar"
                  aria-valuenow="90"
                  aria-valuemin="0"
                  aria-valuemax="100"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Skills Section -->
    <!-- ======= Skills02 Section ======= -->
    <!-- <section id="skills" class="skills section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Our Team</h2>
        </div>
      </div>
    </section> -->
    <section id="skills" class="skills section-bg py-5">
      <div class="container">
        <div class="section-title">
          <h2>Our Team</h2>
        </div>
        <div class="row">
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="team-member">
              <img src="assets/img/teams/1.png" alt="Team Member 1" style="width: 100%;">
              <div class="info">
                <h5>K.G.G.B CHAMARA</h5>
                <p>CEO & Founder</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="team-member">
            <img src="assets/img/teams/2.png" alt="Team Member 1" style="width: 100%;">
              <div class="info">
                <h5>K.G.G.B CHANAKA</h5>
                <p>Marketing Head</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="team-member">
            <img src="assets/img/teams/3.png" alt="Team Member 1" style="width: 100%;">
              <div class="info">
                <h5>ASHEN LALANTHA</h5>
                <p>Project Manager</p>
              </div>
            </div>
          </div>
          <!-- <div class="col-lg-4 col-md-6 mb-4">
            <div class="team-member">
            <img src="assets/img/teams/4.png" alt="Team Member 1" style="width: 100%;">
              <div class="info">
                <h5>SADEEPA</h5>
                <p>Lead Developer</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="team-member">
            <img src="assets/img/teams/5.png" alt="Team Member 1" style="width: 100%;">
              <div class="info">
                <h5>K.G.D.Amodya</h5>
                <p>UI/UX Designer</p>
              </div>
            </div>
          </div> -->
          
          
        </div>
      </div>
    </section>
    <!-- End Skills02 Section -->

    <!-- ======= Resume Section ======= -->
    <section id="resume" class="resume">
      <div class="container">
        <div class="section-title">
          <h2>What's the SDLC?</h2>
          <p>
            <b>The Software Development Life Cycle (SDLC) is a structured process used to design, develop, test, and maintain high-quality software. It ensures that software meets business and technical requirements while being cost-effective and efficient.</b>
          </p>

        </div>

        <div class="row">
          <div class="col-lg-6" data-aos="fade-up">
            <h3 class="resume-title">SDLC Models</h3>
            <div class="resume-item pb-0">
              <h4>There are different SDLC models based on project needs:</h4>
              <ul>
                <li>✅ Waterfall Model – Sequential, step-by-step process (for simple projects).</li>
                <li>✅ Agile Model – Iterative development with flexibility (for dynamic projects).</li>
                <li>✅ Spiral Model – Risk-driven iterative model (for large, complex systems).</li>
              </ul>
            </div>

            <h3 class="resume-title">Basic steps of SDLC</h3>
            <div class="resume-item">
              <h4>Requirement Gathering</h4>
              <h5>Collecting business and user needs through discussions, surveys, or documentation.</h5>
              <!-- <p><em>Rochester Institute of Technology, Rochester, NY</em></p>
              <p>Qui deserunt veniam. Et sed aliquam labore tempore sed quisquam iusto autem sit. Ea vero voluptatum qui ut dignissimos deleniti nerada porti sand markend</p> -->
            </div>
            <div class="resume-item">
              <h4>Requirement Analysis</h4>
              <h5>Evaluating requirements for feasibility, clarity, and potential challenges.</h5>
              <!-- <p><em>Rochester Institute of Technology, Rochester, NY</em></p>
              <p>Quia nobis sequi est occaecati aut. Repudiandae et iusto quae reiciendis et quis Eius vel ratione eius unde vitae rerum voluptates asperiores voluptatem Earum molestiae consequatur neque etlon sader mart dila</p> -->
            </div>
            <div class="resume-item">
              <h4>
                System Design
              </h4>
              <h5>Creating architecture, UI/UX designs, and technical specifications.</h5>
              <!-- <p><em>Rochester Institute of Technology, Rochester, NY</em></p>
              <p>Quia nobis sequi est occaecati aut. Repudiandae et iusto quae reiciendis et quis Eius vel ratione eius unde vitae rerum voluptates asperiores voluptatem Earum molestiae consequatur neque etlon sader mart dila</p> -->
            </div>
            <div class="resume-item">
              <h4>
                System Development
              </h4>
              <h5>Writing the actual code and building the system based on design specifications.</h5>
              <!-- <p><em>Rochester Institute of Technology, Rochester, NY</em></p>
              <p>Quia nobis sequi est occaecati aut. Repudiandae et iusto quae reiciendis et quis Eius vel ratione eius unde vitae rerum voluptates asperiores voluptatem Earum molestiae consequatur neque etlon sader mart dila</p> -->
            </div>
            <div class="resume-item">
              <h4>System Testing</h4>
              <h5> Testing for bugs, security issues, and performance to ensure the system functions as expected.</h5>
              <!-- <p><em>Rochester Institute of Technology, Rochester, NY</em></p>
              <p>Quia nobis sequi est occaecati aut. Repudiandae et iusto quae reiciendis et quis Eius vel ratione eius unde vitae rerum voluptates asperiores voluptatem Earum molestiae consequatur neque etlon sader mart dila</p> -->
            </div>
            <div class="resume-item">
              <h4>System Implementation</h4>
              <h5>Deploying the system for users, including training and data migration.</h5>
              <!-- <p><em>Rochester Institute of Technology, Rochester, NY</em></p>
              <p>Quia nobis sequi est occaecati aut. Repudiandae et iusto quae reiciendis et quis Eius vel ratione eius unde vitae rerum voluptates asperiores voluptatem Earum molestiae consequatur neque etlon sader mart dila</p> -->
            </div>
            <div class="resume-item">
              <h4>System Maintenance</h4>
              <h5>Providing updates, bug fixes, and support to keep the system running smoothly.</h5>
              <!-- <p><em>Rochester Institute of Technology, Rochester, NY</em></p>
              <p>Quia nobis sequi est occaecati aut. Repudiandae et iusto quae reiciendis et quis Eius vel ratione eius unde vitae rerum voluptates asperiores voluptatem Earum molestiae consequatur neque etlon sader mart dila</p> -->
            </div>
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <h3 class="resume-title">Why Choose User Software Company</h3>
            <div class="resume-item">
              <h4>for Your Project</h4>
              <h5>"CeylonPro Software Solutions Company is the number one software
                company that gives real value for your money"</h5>

              <ul>
                <p><em>𝐁𝐫𝐚𝐧𝐝𝐢𝐧𝐠 𝐄𝐱𝐜𝐞𝐥𝐥𝐞𝐧𝐜𝐞 : 𝐂𝐫𝐚𝐟𝐭𝐢𝐧𝐠 𝐈𝐝𝐞𝐧𝐭𝐢𝐭𝐢𝐞𝐬 𝐭𝐡𝐚𝐭 𝐑𝐞𝐬𝐨𝐧𝐚𝐭𝐞</em></p>
                <li>
                  Having a strong brand is an essential factor to take your
                  product to the masses in a highly competitive market. From the
                  logo that represents your brand to adding unique and essential
                  elements (brand name, tagline, text, color, fonts, logo,
                  banner) to it, we can help you build your brand. We can create
                  a business that is unique to you by thinking beyond your
                  imagination.
                </li>
                <p><em>𝐓𝐞𝐜𝐡𝐧𝐢𝐜𝐚𝐥 𝐒𝐮𝐩𝐩𝐨𝐫𝐭 : 𝐄𝐧𝐬𝐮𝐫𝐢𝐧𝐠 𝐒𝐞𝐚𝐦𝐥𝐞𝐬𝐬 𝐎𝐩𝐞𝐫𝐚𝐭𝐢𝐨𝐧𝐬</em></p>
                <li>
                  Ignorance of technology in the digital age can be a cause of
                  reduced productivity. Understanding how to build your business
                  with new technologies, how to apply existing technologies to
                  our business, and how to adapt to the next technologies can be
                  a reason for a big leap in the business world. Therefore, the
                  necessary technical guidance, technical references and
                  implementation can be done together.
                </li>
                <p><em>𝐖𝐞𝐛 𝐏𝐫𝐞𝐬𝐞𝐧𝐜𝐞 𝐑𝐞𝐝𝐞𝐟𝐢𝐧𝐞𝐝 : 𝐍𝐚𝐯𝐢𝐠𝐚𝐭𝐢𝐧𝐠 𝐭𝐡𝐞 𝐃𝐢𝐠𝐢𝐭𝐚𝐥 𝐋𝐚𝐧𝐝𝐬𝐜𝐚𝐩𝐞</em></p>
                <li>
                  An e-commerce website, an informative website can be
                  introduced as an essential service in modern times to sell
                  your services or products in the business world. A website
                  based system is absolutely essential for customer
                  satisfaction, trust, internet based sales and business
                  management. We are capable of creating functional,
                  user-centric websites that serve as the most powerful tool in
                  the digital space. Choose CeylonPro Software Solutions Company to
                  elevate your brand with an attractive website.
                </li>
              </ul>
            </div>
            <div class="resume-item">
              <h4>Follow Use</h4>
              <h5>To contact via whatsApp.</h5>
              <ul>
                <li>
                  Thank you for visiting Our website. If you have any
                  questions or if you would like to discuss a potential project,
                  please do not hesitate to get in touch.
                </li>
                <li>
                  <button style="background-color: #61cf70; border-radius: 10px; border: none; height: 40px;"><a href="#" style="text-decoration: none; color: white;"><b>&nbsp;&nbsp;&nbsp;<i class="bi bi-whatsapp"></i>&nbsp;&nbsp;&nbsp;Join WhatsApp Group&nbsp;&nbsp;&nbsp;</b></a></button>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Resume Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Portfolio</h2>
          <p>
            In each project I undertake, I am committed to delivering
            high-quality work that meets and exceeds client expectations, and
            I am passionate about using technology to solve real-world
            problems and make a positive impact on society.
          </p>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">Web Application</li>
              <li data-filter=".filter-card">web site</li>
              <li data-filter=".filter-web">2D Game</li>
            </ul>
          </div>
        </div>

        <div
          class="row portfolio-container"
          data-aos="fade-up"
          data-aos-delay="100">
          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/lts.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/lts.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="Laboratory Testing Services"><i class="bx bx-plus"></i></a>
                <a
                  href="projects/LaboratoryTestingServices/index.html"
                  target="_blank"
                  title="Visit Site"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/2dgame.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/2dgame.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="Fight And Win"><i class="bx bx-plus"></i></a>
                <a
                  href="projects/UniversityGame/index.html"
                  target="_blank"
                  title="Visit Site"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/rawo.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/rawo.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="SLRawo Web Application"><i class="bx bx-plus"></i></a>
                <a
                  href="https://www.slrawo.com/"
                  target="_blank"
                  title="Visit Site"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/methsuwaarana.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/methsuwaarana.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="Methsuwa Arana Elders Home"><i class="bx bx-plus"></i></a>
                <a
                  href="https://www.methsuwaarana.com/"
                  target="_blank"
                  title="Visit Site"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/yownsaviya.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/yownsaviya.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="Yowun Saviya Sri Lanka"><i class="bx bx-plus"></i></a>
                <a
                  href="#"
                  target="_blank"
                  title="Visit Site(Coming Soon) Wait"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/senu.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/senu.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="SHENU Photography"><i class="bx bx-plus"></i></a>
                <a
                  href="projects/Shenu/index.html"
                  target="_blank"
                  title="Visit Site"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/scan.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/scan.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="SCANIS GLOBAL BPO Company"><i class="bx bx-plus"></i></a>
                <a
                  href="projects/SCANISGLOBALBPO/index.html"
                  target="_blank"
                  title="Visit Site"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/l1.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/l1.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="Online Library & E-Commerce Application"><i class="bx bx-plus"></i></a>
                <a
                  href="#"
                  target="_blank"
                  title="Visit Site(Coming Soon) Wait"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/l2.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/l2.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="Online Library & E-Commerce Application"><i class="bx bx-plus"></i></a>
                <a
                  href="#"
                  target="_blank"
                  title="Visit Site(Coming Soon) Wait"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/l3.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/l3.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="Online Library & E-Commerce Application"><i class="bx bx-plus"></i></a>
                <a
                  href="#"
                  target="_blank"
                  title="Visit Site(Coming Soon) Wait"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/l4.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/l4.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="Online Library & E-Commerce Application"><i class="bx bx-plus"></i></a>
                <a
                  href="#"
                  target="_blank"
                  title="Visit Site(Coming Soon) Wait"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img
                src="assets/img/portfolio/l5.png"
                class="img-fluid"
                alt="" />
              <div class="portfolio-links">
                <a
                  href="assets/img/portfolio/l5.png"
                  data-gallery="portfolioGallery"
                  class="portfolio-lightbox"
                  title="Online Library & E-Commerce Application"><i class="bx bx-plus"></i></a>
                <a
                  href="#"
                  target="_blank"
                  title="Visit Site(Coming Soon) Wait"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Portfolio Section -->

    <!-- product launch start  -->
    <section id="services" class="services">
      <div class="container">
        <div class="section-title">
          <h2>Product Launching & Special Events</h2>
        </div>
        <div class="row">
          <div class="col-12">
            <div
              id="carouselExampleControls"
              class="carousel slide"
              data-bs-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img
                    src="assets/img/pdctLaunch/1.jpeg"
                    class="d-block w-100"
                    alt="..." />
                </div>
                <div class="carousel-item">
                  <img
                    src="assets/img/pdctLaunch/2.jpeg"
                    class="d-block w-100"
                    alt="..." />
                </div>
                <div class="carousel-item">
                  <img
                    src="assets/img/pdctLaunch/3.jpeg"
                    class="d-block w-100"
                    alt="..." />
                </div>
                <div class="carousel-item">
                  <img
                    src="assets/img/pdctLaunch/4.jpeg"
                    class="d-block w-100"
                    alt="..." />
                </div>
                <div class="carousel-item">
                  <img
                    src="assets/img/pdctLaunch/5.jpeg"
                    class="d-block w-100"
                    alt="..." />
                </div>
                <div class="carousel-item">
                  <img
                    src="assets/img/pdctLaunch/6.jpeg"
                    class="d-block w-100"
                    alt="..." />
                </div>
              </div>
              <button
                class="carousel-control-prev"
                type="button"
                data-bs-target="#carouselExampleControls"
                data-bs-slide="prev">
                <span
                  class="carousel-control-prev-icon"
                  aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button
                class="carousel-control-next"
                type="button"
                data-bs-target="#carouselExampleControls"
                data-bs-slide="next">
                <span
                  class="carousel-control-next-icon"
                  aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- product launch end  -->
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">
        <div class="section-title">
          <h2>Our Services</h2>
          <p>
            I offer a range of software development and design services to
            help businesses and individuals achieve their goals and reach
            their full potential in the digital world.
          </p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up">
            <div class="icon"><i class="bi bi-briefcase"></i></div>
            <h4 class="title"><a href="">Frontend Development</a></h4>
            <p class="description">
              I specialize in creating responsive, user-friendly interfaces
              using the latest web technologies and frameworks, including
              HTML5, CSS3, JavaScript, and React.
            </p>
          </div>
          <div
            class="col-lg-4 col-md-6 icon-box"
            data-aos="fade-up"
            data-aos-delay="100">
            <div class="icon"><i class="bi bi-card-checklist"></i></div>
            <h4 class="title"><a href="">Backend Development</a></h4>
            <p class="description">
              I have extensive experience building scalable, efficient, and
              secure server-side applications using a range of programming
              languages and frameworks, including Node.js, PHP, and Ruby on
              Rails.
            </p>
          </div>
          <div
            class="col-lg-4 col-md-6 icon-box"
            data-aos="fade-up"
            data-aos-delay="200">
            <div class="icon"><i class="bi bi-bar-chart"></i></div>
            <h4 class="title">
              <a href="">Mobile Application Development</a>
            </h4>
            <p class="description">
              I create cross-platform mobile applications for iOS and Android
              using technologies like React Native and Flutter.
            </p>
          </div>
          <div
            class="col-lg-4 col-md-6 icon-box"
            data-aos="fade-up"
            data-aos-delay="300">
            <div class="icon"><i class="bi bi-binoculars"></i></div>
            <h4 class="title"><a href="">Design</a></h4>
            <p class="description">
              I offer a range of design services, including user interface
              (UI) design, user experience (UX) design, graphic design, and
              branding.
            </p>
          </div>
          <div
            class="col-lg-4 col-md-6 icon-box"
            data-aos="fade-up"
            data-aos-delay="400">
            <div class="icon"><i class="bi bi-brightness-high"></i></div>
            <h4 class="title"><a href="">Ethical hacking</a></h4>
            <p class="description">
              I can help identify and address potential security
              vulnerabilities in your software systems to ensure they are as
              secure as possible.
            </p>
          </div>
          <div
            class="col-lg-4 col-md-6 icon-box"
            data-aos="fade-up"
            data-aos-delay="500">
            <div class="icon"><i class="bi bi-calendar4-week"></i></div>
            <h4 class="title"><a href="">Teaching And Mentorship</a></h4>
            <p class="description">
              I offer individual and group mentoring sessions and workshops on
              a range of software engineering topics, including programming,
              web development, and cybersecurity.
            </p>
          </div>
        </div>
      </div>
    </section>
    <!-- End Services Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Testimonials</h2>
          <p>
            Testimonials from past clients and what my students have said
            about me?
          </p>
        </div>

        <div
          class="testimonials-slider swiper"
          data-aos="fade-up"
          data-aos-delay="100">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="testimonial-item" data-aos="fade-up">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Thank you sir...for helping me make my it project
                  super...highly recommend sir..thanks a lot sir...
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img
                  src="assets/img/testimonials/testimonials-1.png"
                  class="testimonial-img"
                  alt="" />
                <h3>Dineth Thimira</h3>
                <h4>Client</h4>
              </div>
            </div>
            <!-- End testimonial item -->

            <div class="swiper-slide">
              <div
                class="testimonial-item"
                data-aos="fade-up"
                data-aos-delay="100">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I have never met a teacher like you and should be lucky to
                  learn from you. Not only the ICT but also shows the way to
                  succeed in life. You are the best teacher I have met in my
                  life. I wish you good health and long life.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img
                  src="assets/img/testimonials/testimonials-2.png"
                  class="testimonial-img"
                  alt="" />
                <h3>Rishmi</h3>
                <h4>Student</h4>
              </div>
            </div>
            <!-- End testimonial item -->

            <div class="swiper-slide">
              <div
                class="testimonial-item"
                data-aos="fade-up"
                data-aos-delay="200">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I am very thankful for the successful completion of my
                  project in an orderly and orderly manner that I did not
                  expect.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img
                  src="assets/img/testimonials/testimonials-3.jpeg"
                  class="testimonial-img"
                  alt="" />
                <h3>Ragindra</h3>
                <h4>Client</h4>
              </div>
            </div>
            <!-- End testimonial item -->

            <div class="swiper-slide">
              <div
                class="testimonial-item"
                data-aos="fade-up"
                data-aos-delay="300">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  U r doing a great job! Specially I like your works. Your
                  efforts to complete your tasks in the best possible way are
                  tremendous. I am lucky to meet a developer like you.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img
                  src="assets/img/testimonials/testimonials-4.jpeg"
                  class="testimonial-img"
                  alt="" />
                <h3>Ravini</h3>
                <h4>Client</h4>
              </div>
            </div>
            <!-- End testimonial item -->

            <div class="swiper-slide">
              <div
                class="testimonial-item"
                data-aos="fade-up"
                data-aos-delay="400">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I am delighted to share my thoughts on the excellent work
                  you have completed. Your dedication and hard work have
                  certainly paid off, and it shows in the quality of your
                  project. Your attention to detail and creative approach has
                  resulted in a truly impressive outcome that reflects your
                  expertise and commitment to excellence. I am impressed with
                  the level of professionalism and skill you demonstrated
                  throughout the project, and your ability to exceed
                  expectations is truly commendable. It has been a pleasure
                  working with you, and I look forward to future
                  collaborations. Thank you for your outstanding work and
                  contributions.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img
                  src="assets/img/testimonials/testimonials-5.jpeg"
                  class="testimonial-img"
                  alt="" />
                <h3>Misheli</h3>
                <h4>Client</h4>
              </div>
            </div>
            <!-- End testimonial item -->

            <div class="swiper-slide">
              <div
                class="testimonial-item"
                data-aos="fade-up"
                data-aos-delay="400">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Really works very well. A very good customer handling will
                  complete the work very quickly and efficiently in the
                  relevant time. And fulfills his responsibility as a teacher.
                  highly reccomad.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img
                  src="assets/img/testimonials/testimonials-6.jpeg"
                  class="testimonial-img"
                  alt="" />
                <h3>Sachith</h3>
                <h4>Client</h4>
              </div>
            </div>
            <!-- End testimonial item -->
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </section>
    <!-- End Testimonials Section -->

    <!-- ======= Client Section ======= -->
    <section id="testimonials" style="background-color: #CDF5FD;">
      <div class="container">
        <div class="section-title">
          <h2 class="text-black">Our Clients</h2>
          <p class="text-black">
            Below you can see the logos of the organizations that have created
            software in association with our software company.
          </p>
        </div>
        <div class="row" style="display: flex; align-items: center">
          <div class="col-6 col-md-3 col-lg-2 col-xlg-2 col-xxlg-2">
            <div
              class="card mt-2"
              style="width: 8rem; display: flex; align-items: center">
              <div
                class="card-body"
                style="
                    display: flex;
                    justify-content: center;
                    align-items: center;
                  ">
                <img
                  src="assets/img/compleadprojectLogos/2.png"
                  width="100px" />
              </div>
            </div>
          </div>
          <div class="col-6 col-md-3 col-lg-2 col-xlg-2 col-xxlg-2">
            <div class="card mt-2" style="width: 8rem">
              <div
                class="card-body"
                style="
                    display: flex;
                    justify-content: center;
                    align-items: center;
                  ">
                <img
                  src="assets/img/compleadprojectLogos/favicon.png"
                  width="100px" />
              </div>
            </div>
          </div>
          <div class="col-6 col-md-3 col-lg-2 col-xlg-2 col-xxlg-2">
            <div class="card mt-2" style="width: 8rem">
              <div
                class="card-body"
                style="
                    display: flex;
                    justify-content: center;
                    align-items: center;
                  ">
                <img
                  src="assets/img/compleadprojectLogos/logo-default.png"
                  width="100px" />
              </div>
            </div>
          </div>
          <div class="col-6 col-md-3 col-lg-2 col-xlg-2 col-xxlg-2">
            <div class="card mt-2" style="width: 8rem">
              <div
                class="card-body"
                style="
                    display: flex;
                    justify-content: center;
                    align-items: center;
                  ">
                <img
                  src="assets/img/compleadprojectLogos/logo.png"
                  width="100px" />
              </div>
            </div>
          </div>
          <div class="col-6 col-md-3 col-lg-2 col-xlg-2 col-xxlg-2">
            <div class="card mt-2" style="width: 8rem">
              <div
                class="card-body"
                style="
                    display: flex;
                    justify-content: center;
                    align-items: center;
                  ">
                <img
                  src="assets/img/compleadprojectLogos/rawologo.png"
                  width="100px" />
              </div>
            </div>
          </div>
          <div class="col-6 col-md-3 col-lg-2 col-xlg-2 col-xxlg-2">
            <div class="card mt-2" style="width: 8rem">
              <div
                class="card-body"
                style="display: flex; align-items: center">
                <img
                  src="assets/img/compleadprojectLogos/WhatsApp Image 2023-06-07 at 13.01.15.jpeg"
                  width="100px" />
              </div>
            </div>
          </div>
          <div class="col-6 col-md-3 col-lg-2 col-xlg-2 col-xxlg-2">
            <div class="card mt-2" style="width: 8rem">
              <div
                class="card-body"
                style="display: flex; align-items: center">
                <img
                  src="assets/img/compleadprojectLogos/YSLogo-removebg-preview (1).png"
                  width="100px" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Client Section -->
    <!-- My Commpany Start  -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Services Available from Us</h2>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="service-list">
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-phone"></i> Mobile Application</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-upc-scan"></i> POS System</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-cash"></i> AdSense Targeted Website</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-pencil-square"></i> Blog Websites</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-cart"></i> E-Commerce Website</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-person-badge"></i> Portfolio Website</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-building"></i> Company or Business Website</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-cup"></i> Hotel / Restaurant Website</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-calendar-check"></i> Booking Website</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-camera-reels"></i> Entertainment Websites</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-book"></i> Educational Websites</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-laptop"></i> E-learning / LMS Website</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-geo-alt"></i> Tourism / Travel Website</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-house"></i> Hotel Booking System</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-shop"></i> Online Store</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-truck"></i> Shipping and Delivery Website</b></div>
              <div class="service-item fs-5 upmouse"><b><i class="bi bi-tools"></i> Customize Your Website for Your Requirements</b></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- My Commpany End  -->
    <!-- My Team Start  -->
    <!-- <section id="testimonials" class="bg-secondary">
        <div class="container">
          <div class="section-title">
            <h2 class="text-white">My Team</h2>
            <p class="text-white">
              Below you can see the logos of the organizations that have created
              software in association with our software company.
            </p>
          </div>
        </div>
      </section> -->
    <!-- My Team End  -->
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">
        <div class="section-title">
          <h2>Contact</h2>

          <p>
            I am also available for freelance work and consulting engagements.
            If you are interested in working with me, please provide some
            details about your project or your consulting needs, and I will
            get back to you as soon as possible.
          </p>
          <p>Thank you again for your interest in Our work.</p>
        </div>

        <div class="row" data-aos="fade-in">
          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>Monaragala, Sri Lanka</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>ceylonpro914@gmail.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p>+94 70 593 6264</p>
              </div>

              <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe> -->

              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31688.233851760546!2d81.32337546056479!3d6.887102065302025!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae45a9ddf60af13%3A0xaaeaff47009fda28!2sMonaragala!5e0!3m2!1sen!2slk!4v1743317593683!5m2!1sen!2slk" width="100%"
                height="290px"
                style="border: 0"
                allowfullscreen=""
                loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form role="form" class="php-email-form">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Your Name</label>
                  <input
                    type="text"
                    name="name"
                    class="form-control"
                    id="name"
                    required />
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Your Mobile</label>
                  <input
                    type="number"
                    class="form-control"
                    name="number"
                    id="number"
                    required />
                </div>
              </div>
              <div class="form-group">
                <label for="name">Your Email</label>
                <input
                  type="email"
                  class="form-control"
                  name="email"
                  id="email"
                  required />
              </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea
                  class="form-control"
                  name="message"
                  id="message"
                  rows="10"
                  required></textarea>
              </div>
              <!-- <div class="my-3">
                  <div class="loading">Loading</div>
                  <div class="error-message"></div>
                  <div class="sent-message">
                    Your message has been sent. Thank you!
                  </div>
                </div> -->
              <div class="text-center">
                <button class="btn btn-primary" onclick="reqwestMasseg();">
                  Send Message
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
    <!-- End Contact Section -->
  </main>
  <!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; 2021 <strong><span>CeylonePro</span></strong>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/ -->
        Designed by <a href="#">CeylonePro Software Solutions</a>
      </div>
    </div>
  </footer>
  <!-- End  Footer -->

  <a
    href="#"
    class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="curserStyle.js"></script>
</body>

</html>