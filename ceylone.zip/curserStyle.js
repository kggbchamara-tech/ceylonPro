
(function () {

    const link = document.querySelectorAll('nav > .hover-this');
    const cursor = document.querySelector('.cursor');

    const animateit = function (e) {
          const span = this.querySelector('span');
          const { offsetX: x, offsetY: y } = e,
          { offsetWidth: width, offsetHeight: height } = this,

          move = 25,
          xMove = x / width * (move * 2) - move,
          yMove = y / height * (move * 2) - move;

          span.style.transform = `translate(${xMove}px, ${yMove}px)`;

          if (e.type === 'mouseleave') span.style.transform = '';
    };

    const editCursor = e => {
          const { clientX: x, clientY: y } = e;
          cursor.style.left = x + 'px';
          cursor.style.top = y + 'px';
    };

    link.forEach(b => b.addEventListener('mousemove', animateit));
    link.forEach(b => b.addEventListener('mouseleave', animateit));
    window.addEventListener('mousemove', editCursor);

})();

var ClientEmail;
function reqwestMasseg(){
      var name = document.getElementById("name").value;
      var number = document.getElementById("number").value;
      var email = document.getElementById("email").value;
      var message = document.getElementById("message").value;
      // alert(name);
      // alert(number);
      // alert(email);
      // alert(message);

      var form = new FormData();
      form.append("name",name);
      form.append("number",number);
      form.append("email",email);
      form.append("message",message);

      var request = new XMLHttpRequest();
      request.onreadystatechange=function (){
            if(request.readyState==4){
                  var text = request.responseText;
                  var JsObject = JSON.parse(text);
                  ClientEmail = JsObject.emai;
                  responesFunction();
            }
      };

      request.open("POST","forms/sendMasseg.php",true);
      request.send(form);

}

function responesFunction(){
      var form = new FormData();
      form.append("ClientEmail",ClientEmail);

      var request = new XMLHttpRequest();
      request.onreadystatechange=function (){
            if(request.readyState==4){
                  var text = request.responseText;
                  if(text=="Success"){
                        alert("Your message has been sent. We will contact You Soon So stay tuned for Email, Call Or Messages. Thank you!");
                        window.location.reload();
                  }else{
                      alert(text);  
                  }
                  
            }
      };

      request.open("POST","forms/responseMasseg.php",true);
      request.send(form);
}