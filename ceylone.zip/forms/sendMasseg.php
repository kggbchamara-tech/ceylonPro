<?php

$name = htmlspecialchars($_POST["name"]);
$email = $_POST["email"];
$phoneNumber = $_POST["number"];
$comment = htmlspecialchars($_POST["message"]);
require "SMTP.php";
require "PHPMailer.php";
require "Exception.php";
use PHPMailer\PHPMailer\PHPMailer;

if (empty($name)) {
    echo ("Please Insert the Name");
} else if (empty($phoneNumber)) {
  echo ("Please Insert the Mobile");
}else if (empty($email)) {
  echo ("Please Insert the Email");
} else if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
  echo("Invalid Email");
} else if (empty($comment)) {
  echo ("Please Enter the Your Massege");
} else{
    $mail = new PHPMailer;
    $mail->IsSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'charmarapreethikumara@gmail.com';
    $mail->Password = 'zbawpmzklctlxwpa';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->setFrom('charmarapreethikumara@gmail.com', 'Clients Request');
    $mail->addReplyTo('charmarapreethikumara@gmail.com', 'Clients Request');
    $mail->addAddress('kggbchamara@gmail.com');
    $mail->isHTML(true);
    $mail->Subject = 'CHAMA Programmer Clients Request';
    $bodyContent = '<!doctype html>
    <html lang="en">
      <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        
        <!-- CHAMA Programmer CSS File -->
      </head>
      <body>
        <div class="container-fluid">
          <!-- row 01 start  -->
          <div class="row">
            <div class="col-12 text text-center" style="background-color:#4f5aba;">
            <h1 style="text-aling:center;">CHAMA Programmer Software Company</h1>
            <p>"CHAMA Programmer Software Company is the number one software company that gives real value for your money"</p>
            
            </div>
            <hr/>
            <div class="col-12">
            <p> <b>User Name : </b>'.$name.'</p>
            <p> <b>User Phone Number : </b>'.$phoneNumber.'</p>
            <p> <b>User Email : </b>'.$email.'</p>
            </div>
            <div class="col-12">
            <h3>User Comment :</h3>
            <p>'.$comment.'</p>
            </div>
            <hr/>
            <div style="background-color:#4f5aba; text-aling:center;"><p>Copyright © 2023 CHAMA Programmer, All
            rights reserved.</p></div>
          </div>
          <!-- row 01 End  -->
        </div>
    
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        
        <!-- CHAMA Programmer JavaScript File -->
      </body>
    </html>';
    $mail->Body    = $bodyContent;

    if (!$mail->send()) {
        echo 'Users Request sending failed';
    } else {
        
        // $emaiArray = array();
        $emailObject = new stdClass();
        $emailObject->emai = $email;
        // $emaiArray[] = $emailObject;
        $responseJSON = json_encode($emailObject);
        echo ($responseJSON);
    }

}


?>